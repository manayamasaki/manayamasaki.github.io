const message = 'Hello world' // Try edit me

// Update header text
document.querySelector('#header').innerHTML = message

// Log to console
console.log(message)

const arr = ["waffle", "chocolate", "mashmarrow"];
console.log(arr)

for(let item of arr){
  console.log(item)
}

sum = 0;
for( i=1 ; i<=100 ; ++i )
{
	sum = sum + i;
}
console.log(sum);

